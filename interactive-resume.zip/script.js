// Attach event listeners to all input fields
let inputs = document.querySelectorAll("input");
inputs.forEach(input => {
  input.addEventListener("input", updateResume);
});

// Main function to update the resume preview in real time
function updateResume() {
  document.getElementById("rname").innerText  = document.getElementById("name").value;
  document.getElementById("rrole").innerText  = document.getElementById("role").value;
  document.getElementById("remail").innerText = document.getElementById("email").value;
  document.getElementById("rphone").innerText = document.getElementById("phone").value;

  document.getElementById("rcollege").innerText       = document.getElementById("college").value;
  document.getElementById("rdegree").innerText        = document.getElementById("degree").value;
  document.getElementById("ryear").innerText          = document.getElementById("year").value;

  document.getElementById("rproject1").innerText      = document.getElementById("project1").value;
  document.getElementById("rproject2").innerText      = document.getElementById("project2").value;

  document.getElementById("rexperience").innerText    = document.getElementById("experience").value;
  document.getElementById("rcertifications").innerText = document.getElementById("certifications").value;

  document.getElementById("rgithub").href             = document.getElementById("github").value;
  document.getElementById("rlinkedin").href           = document.getElementById("linkedin").value;

  updateSkills();
}

// Render skill bars dynamically
function updateSkills() {
  let skillContainer = document.getElementById("rskills");
  skillContainer.innerHTML = "";

  let skillsValue = document.getElementById("skills").value;
  if (!skillsValue.trim()) return;

  let skillList = skillsValue.split(",");

  skillList.forEach(skill => {
    skill = skill.trim();
    if (!skill) return;

    let wrapper = document.createElement("div");
    wrapper.className = "skill";

    let label = document.createElement("div");
    label.className = "skill-label";
    label.innerText = skill;

    let bar = document.createElement("div");
    bar.className = "skill-bar";
    bar.style.width = Math.floor(Math.random() * 60 + 40) + "%"; // 40–100%

    wrapper.appendChild(label);
    wrapper.appendChild(bar);
    skillContainer.appendChild(wrapper);
  });
}

// Handle photo upload and preview
document.getElementById("photo").onchange = function () {
  let reader = new FileReader();
  reader.onload = function (e) {
    let rphoto = document.getElementById("rphoto");
    rphoto.src = e.target.result;
    rphoto.style.display = "block";
  };
  reader.readAsDataURL(this.files[0]);
};

// Toggle dark mode
function toggleMode() {
  document.body.classList.toggle("dark");
  let btn = document.querySelector(".top-buttons button");
  btn.innerText = document.body.classList.contains("dark") ? "Light Mode" : "Dark Mode";
}

// Download resume as PDF
function downloadPDF() {
  let element = document.getElementById("resume");
  html2pdf().from(element).save("My_Resume.pdf");
}
