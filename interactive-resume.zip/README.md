# 📄 Interactive Resume Builder

A two-panel web application where users fill out a form and see their resume generate **live in real time** on the right side.

## 🚀 Features

- **Live Preview** – Resume updates instantly as you type using DOM Manipulation & Event Listeners
- **Photo Upload** – Upload a profile photo that appears on the resume
- **Skill Bars** – Skills entered as comma-separated values are rendered with visual progress bars
- **Dark Mode** – Toggle between light and dark themes
- **Download as PDF** – Export your resume directly from the browser using `html2pdf.js`

## 🛠️ Tech Stack

- HTML5
- CSS3
- JavaScript (Vanilla)
- [html2pdf.js](https://github.com/eKoopmans/html2pdf.js)

## 📁 Project Structure

```
interactive-resume-builder/
│
├── index.html       # Main HTML structure (two-panel layout)
├── style.css        # Styling including dark mode & skill bars
├── script.js        # Live update logic, PDF export, dark mode toggle
└── README.md        # Project documentation
```

## ▶️ How to Run

1. Clone the repository:
   ```bash
   git clone https://github.com/your-username/interactive-resume-builder.git
   ```
2. Open `index.html` in your browser — no server needed!

## 📸 How to Use

1. Fill in your details in the **left panel**
2. Watch your resume update **live** on the **right panel**
3. Upload a profile photo
4. Click **Download Resume** to save as PDF

## 👤 Author

**Your Name**  
[GitHub](https://github.com/your-username) | [LinkedIn](https://linkedin.com/in/your-username)
